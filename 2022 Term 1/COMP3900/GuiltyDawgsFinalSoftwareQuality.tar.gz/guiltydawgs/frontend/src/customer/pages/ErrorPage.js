import React from 'react'

/*
  Error page (when the url is not valid)
*/
const ErrorPage = () => {
  return (
    <div>Error: Page not found</div>
  )
}

export default ErrorPage